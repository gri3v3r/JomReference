DROP TABLE IF EXISTS `#__jomreference_recommendations`;
DROP TABLE IF EXISTS `#__jomreference_ratings`;
DROP TABLE IF EXISTS `#__jomreference_businessinfo`;
DROP TABLE IF EXISTS `#__jomreference_relations`;
